exports.up = function(knex) {
  // This is a placeholder migration
  return Promise.resolve();
};

exports.down = function(knex) {
  return Promise.resolve();
};
