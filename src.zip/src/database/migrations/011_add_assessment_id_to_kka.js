/**
 * Add assessment_id column to kka table for manual assessments
 * @param {import('knex').Knex} knex
 */
exports.up = function(knex) {
  return knex.schema.alterTable('kka', function(table) {
    table.uuid('assessment_id').references('id').inTable('assessment').onDelete('CASCADE');
    table.index(['assessment_id']);
  });
};

exports.down = function(knex) {
  return knex.schema.alterTable('kka', function(table) {
    table.dropIndex(['assessment_id']);
    table.dropColumn('assessment_id');
  });
};
