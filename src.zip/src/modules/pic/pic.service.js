/**
 * PIC (Person In Charge) Service
 * Manages PIC assignments for factors and parameters
 */
const { getConnection } = require('../../config/database');
const logger = require('../../utils/logger');
const { v4: uuidv4 } = require('uuid');

class PICService {
  constructor() {
    this.db = getConnection();
  }

  /**
   * Assign PIC to a target (factor or parameter)
   */
  async assignPIC(targetType, targetId, unitBidangId, userId) {
    const trx = await this.db.transaction();
    try {
      // Validate target type
      if (!['factor', 'parameter'].includes(targetType)) {
        throw new Error('Invalid target type. Must be "factor" or "parameter"');
      }

      // Validate target exists
      const target = await trx(targetType).where('id', targetId).first();
      if (!target) {
        throw new Error(`${targetType} not found`);
      }

      // Validate unit bidang exists
      const unitBidang = await trx('unit_bidang')
        .where('id', unitBidangId)
        .where('is_active', true)
        .first();
      
      if (!unitBidang) {
        throw new Error('Unit bidang not found or inactive');
      }

      // Check if PIC assignment already exists
      const existingAssignment = await trx('pic_map')
        .where('target_type', targetType)
        .where('target_id', targetId)
        .first();

      if (existingAssignment) {
        // Update existing assignment
        await trx('pic_map')
          .where('id', existingAssignment.id)
          .update({
            unit_bidang_id: unitBidangId,
            updated_at: new Date()
          });
        
        logger.info(`PIC assignment updated: ${targetType} ${targetId} -> unit bidang ${unitBidangId}`);
      } else {
        // Create new assignment
        await trx('pic_map').insert({
          id: uuidv4(),
          target_type: targetType,
          target_id: targetId,
          unit_bidang_id: unitBidangId,
          created_at: new Date(),
          updated_at: new Date()
        });
        
        logger.info(`PIC assignment created: ${targetType} ${targetId} -> unit bidang ${unitBidangId}`);
      }

      await trx.commit();
      
      // Return assignment with unit bidang details
      const assignment = await this.getPICAssignment(targetType, targetId);
      return assignment;

    } catch (error) {
      await trx.rollback();
      logger.error('Error in assignPIC:', error);
      throw error;
    }
  }

  /**
   * Remove PIC assignment
   */
  async removePIC(targetType, targetId) {
    try {
      const deletedRows = await this.db('pic_map')
        .where('target_type', targetType)
        .where('target_id', targetId)
        .del();

      if (deletedRows === 0) {
        throw new Error('PIC assignment not found');
      }

      logger.info(`PIC assignment removed: ${targetType} ${targetId}`);
      return { success: true };

    } catch (error) {
      logger.error('Error in removePIC:', error);
      throw error;
    }
  }

  /**
   * Get PIC assignment for a target
   */
  async getPICAssignment(targetType, targetId) {
    try {
      const assignment = await this.db('pic_map')
        .select(
          'pic_map.*',
          'unit_bidang.kode as unit_kode',
          'unit_bidang.nama as unit_nama',
          'unit_bidang.deskripsi as unit_deskripsi'
        )
        .leftJoin('unit_bidang', 'pic_map.data_unit_id', 'unit_bidang.id')
        .where('pic_map.target_type', targetType)
        .where('pic_map.target_id', targetId)
        .first();

      return assignment;

    } catch (error) {
      logger.error('Error in getPICAssignment:', error);
      throw error;
    }
  }

  /**
   * Get all PIC assignments for an assessment
   */
  async getPICAssignmentsByAssessment(assessmentId) {
    try {
      const assignments = await this.db('pic_map')
        .select(
          'pic_map.*',
          'unit_bidang.kode as unit_kode',
          'unit_bidang.nama as unit_nama',
          'unit_bidang.deskripsi as unit_deskripsi',
          'factor.kode as factor_kode',
          'factor.nama as factor_nama',
          'parameter.kode as parameter_kode',
          'parameter.nama as parameter_nama',
          'aspect.kode as aspect_kode',
          'aspect.nama as aspect_nama',
          'kka.kode as kka_kode',
          'kka.nama as kka_nama'
        )
        .leftJoin('unit_bidang', 'pic_map.data_unit_id', 'unit_bidang.id')
        .leftJoin('factor', function() {
          this.on('pic_map.target_id', '=', 'factor.id')
            .andOn('pic_map.target_type', '=', this.db.raw('?', ['factor']));
        })
        .leftJoin('parameter', function() {
          this.on('pic_map.target_id', '=', 'parameter.id')
            .andOn('pic_map.target_type', '=', this.db.raw('?', ['parameter']))
            .orOn('factor.parameter_id', '=', 'parameter.id');
        })
        .leftJoin('aspect', 'parameter.aspect_id', 'aspect.id')
        .leftJoin('kka', 'aspect.kka_id', 'kka.id')
        .leftJoin('response', function() {
          this.on('response.factor_id', '=', 'factor.id')
            .andOn('response.assessment_id', '=', this.db.raw('?', [assessmentId]));
        })
        .where(function() {
          this.whereNotNull('response.id')
            .orWhere('pic_map.target_type', 'parameter');
        })
        .orderBy('kka.sort')
        .orderBy('aspect.sort')
        .orderBy('parameter.sort')
        .orderBy('factor.sort');

      return assignments;

    } catch (error) {
      logger.error('Error in getPICAssignmentsByAssessment:', error);
      throw error;
    }
  }

  /**
   * Get PIC assignments for a unit bidang
   */
  async getPICAssignmentsByUnit(unitBidangId) {
    try {
      const assignments = await this.db('pic_map')
        .select(
          'pic_map.*',
          'unit_bidang.kode as unit_kode',
          'unit_bidang.nama as unit_nama',
          'factor.kode as factor_kode',
          'factor.nama as factor_nama',
          'parameter.kode as parameter_kode',
          'parameter.nama as parameter_nama'
        )
        .leftJoin('unit_bidang', 'pic_map.data_unit_id', 'unit_bidang.id')
        .leftJoin('factor', function() {
          this.on('pic_map.target_id', '=', 'factor.id')
            .andOn('pic_map.target_type', '=', this.db.raw('?', ['factor']));
        })
        .leftJoin('parameter', function() {
          this.on('pic_map.target_id', '=', 'parameter.id')
            .andOn('pic_map.target_type', '=', this.db.raw('?', ['parameter']));
        })
        .where('pic_map.data_unit_id', unitBidangId)
        .orderBy('pic_map.created_at', 'desc');

      return assignments;

    } catch (error) {
      logger.error('Error in getPICAssignmentsByUnit:', error);
      throw error;
    }
  }

  /**
   * Bulk assign PICs from assessment data
   */
  async bulkAssignPICs(assessmentId, assignments, userId) {
    const trx = await this.db.transaction();
    try {
      const results = [];

      for (const assignment of assignments) {
        const { targetType, targetId, unitBidangId } = assignment;
        
        // Validate and assign PIC
        const result = await this.assignPIC(targetType, targetId, unitBidangId, userId);
        results.push(result);
      }

      await trx.commit();
      logger.info(`Bulk PIC assignment completed for assessment ${assessmentId}: ${results.length} assignments`);
      
      return results;

    } catch (error) {
      await trx.rollback();
      logger.error('Error in bulkAssignPICs:', error);
      throw error;
    }
  }
}

module.exports = PICService;
