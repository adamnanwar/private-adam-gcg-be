/**
 * PIC (Person In Charge) Routes
 */
const express = require('express');
const PICController = require('./pic.controller');
const { authenticateToken, requireRole } = require('../../middlewares/auth');

const router = express.Router();
const picController = new PICController();

// Apply auth middleware to all routes
router.use(authenticateToken);

// POST /api/v1/pic/assign - Assign PIC to target (admin and user)
router.post('/assign', requireRole(['admin', 'user']), picController.assignPIC.bind(picController));

// DELETE /api/v1/pic/:target_type/:target_id - Remove PIC assignment (admin and user)
router.delete('/:target_type/:target_id', requireRole(['admin', 'user']), picController.removePIC.bind(picController));

// GET /api/v1/pic/:target_type/:target_id - Get PIC assignment for target (admin and user)
router.get('/:target_type/:target_id', requireRole(['admin', 'user']), picController.getPICAssignment.bind(picController));

// GET /api/v1/pic/assessment/:assessmentId - Get all PIC assignments for assessment (admin and user)
router.get('/assessment/:assessmentId', requireRole(['admin', 'user']), picController.getPICAssignmentsByAssessment.bind(picController));

// GET /api/v1/pic/unit/:unitBidangId - Get PIC assignments for unit bidang (admin and user)
router.get('/unit/:unitBidangId', requireRole(['admin', 'user']), picController.getPICAssignmentsByUnit.bind(picController));

// POST /api/v1/pic/assessment/:assessmentId/bulk - Bulk assign PICs for assessment (admin and user)
router.post('/assessment/:assessmentId/bulk', requireRole(['admin', 'user']), picController.bulkAssignPICs.bind(picController));

module.exports = router;
