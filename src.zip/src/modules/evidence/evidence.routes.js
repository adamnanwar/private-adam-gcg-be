const express = require('express');
const evidenceController = require('./evidence.controller');
const evidenceService = require('./evidence.service');
const { authenticateToken, requireRole } = require('../../middlewares/auth');

const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticateToken);

// Evidence upload routes
router.post('/assignment/:assignmentId/upload', evidenceController.uploadEvidence);
router.get('/assignment/:assignmentId', evidenceController.getEvidenceByAssignment);
router.delete('/:evidenceId', evidenceController.deleteEvidence);

// Evidence viewing routes (for assessors)
router.get('/factor/:factorId', requireRole(['admin', 'user']), evidenceController.getEvidenceByFactor);

// File serving route
router.get('/file/:filename', evidenceController.serveEvidence);

// Multer middleware for file uploads
router.use(evidenceService.getUploadMiddleware());

module.exports = router;