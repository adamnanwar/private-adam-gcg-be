const express = require('express');
const AssessmentScoringController = require('./assessment-scoring.controller');

function createAssessmentScoringRoutes(db) {
  const router = express.Router();
  const controller = new AssessmentScoringController(db);

  // GET /assessments/:assessmentId/kka/:kkaId/score
  router.get('/:assessmentId/kka/:kkaId/score', controller.getKkaScore);

  // POST /assessments/:assessmentId/kka/:kkaId/aoi/generate
  router.post('/:assessmentId/kka/:kkaId/aoi/generate', controller.generateAoiForKka);

  // GET /assessments/:assessmentId/aoi/candidates
  router.get('/:assessmentId/aoi/candidates', controller.listAoiCandidates);

  return router;
}

module.exports = { createAssessmentScoringRoutes };
