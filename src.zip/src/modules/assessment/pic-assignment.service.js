const { getConnection } = require('../../config/database');
const emailService = require('../../services/email.service');
const logger = require('../../utils/logger-simple');
const { randomUUID } = require('crypto');

class PICAssignmentService {
  constructor() {
    this.db = getConnection();
  }

  async assignPICToAssessment(assessmentId, factorAssignments) {
    const trx = await this.db.transaction();
    
    try {
      // Get assessment details
      const assessment = await trx('assessment')
        .where('id', assessmentId)
        .first();

      if (!assessment) {
        throw new Error('Assessment not found');
      }

      // Get all factors with their PIC assignments
      const factors = await trx('factor')
        .leftJoin('unit_bidang', 'factor.pic_unit_bidang_id', 'unit_bidang.id')
        .select(
          'factor.*',
          'unit_bidang.nama as unit_nama',
          'unit_bidang.kode as unit_kode'
        )
        .whereIn('factor.id', factorAssignments.map(f => f.factor_id));

      // Group factors by unit bidang
      const unitGroups = {};
      factors.forEach(factor => {
        if (factor.pic_unit_bidang_id) {
          if (!unitGroups[factor.pic_unit_bidang_id]) {
            unitGroups[factor.pic_unit_bidang_id] = {
              unit_id: factor.pic_unit_bidang_id,
              unit_nama: factor.unit_nama,
              unit_kode: factor.unit_kode,
              factors: []
            };
          }
          unitGroups[factor.pic_unit_bidang_id].factors.push(factor);
        }
      });

      // Get users for each unit bidang
      const picUsers = [];
      for (const unitId of Object.keys(unitGroups)) {
        const users = await trx('users')
          .where('unit_bidang_id', unitId)
          .andWhere('is_active', true)
          .select('*');

        picUsers.push(...users.map(user => ({
          ...user,
          unit_nama: unitGroups[unitId].unit_nama,
          unit_kode: unitGroups[unitId].unit_kode,
          assigned_factors: unitGroups[unitId].factors
        })));
      }

      // Send email notifications
      if (picUsers.length > 0) {
        await emailService.sendAssessmentNotification(assessment, picUsers, factors);
        logger.info(`📧 PIC assignment notifications sent for assessment ${assessmentId}`);
      }

      // Create PIC assignments in database
      const picAssignments = [];
      for (const assignment of factorAssignments) {
        picAssignments.push({
          id: randomUUID(),
          assessment_id: assessmentId,
          factor_id: assignment.factor_id,
          pic_user_id: assignment.pic_user_id,
          assigned_at: new Date(),
          status: 'assigned',
          created_at: new Date(),
          updated_at: new Date()
        });
      }

      await trx('pic_map').insert(picAssignments);

      // Update assessment status to in_progress
      await trx('assessment')
        .where('id', assessmentId)
        .update({
          status: 'in_progress',
          updated_at: new Date()
        });

      await trx.commit();

      return {
        assessment,
        picUsers,
        assignments: picAssignments
      };
    } catch (error) {
      await trx.rollback();
      logger.error('Error in assignPICToAssessment:', error);
      throw error;
    }
  }

  async getPICAssignments(assessmentId) {
    try {
      const assignments = await this.db('pic_map')
        .leftJoin('factor', 'pic_map.factor_id', 'factor.id')
        .leftJoin('parameter', 'factor.parameter_id', 'parameter.id')
        .leftJoin('aspect', 'parameter.aspect_id', 'aspect.id')
        .leftJoin('kka', 'aspect.kka_id', 'kka.id')
        .leftJoin('users', 'pic_map.pic_user_id', 'users.id')
        .leftJoin('unit_bidang', 'factor.pic_unit_bidang_id', 'unit_bidang.id')
        .select(
          'pic_map.*',
          'factor.kode as factor_kode',
          'factor.nama as factor_nama',
          'parameter.kode as parameter_kode',
          'parameter.nama as parameter_nama',
          'aspect.kode as aspect_kode',
          'aspect.nama as aspect_nama',
          'kka.kode as kka_kode',
          'kka.nama as kka_nama',
          'users.name as pic_name',
          'users.email as pic_email',
          'unit_bidang.nama as unit_nama'
        )
        .where('pic_map.assessment_id', assessmentId);

      return assignments;
    } catch (error) {
      logger.error('Error in getPICAssignments:', error);
      throw error;
    }
  }

  async getPICAssessments(userId) {
    try {
      const assessments = await this.db('pic_map')
        .leftJoin('assessment', 'pic_map.assessment_id', 'assessment.id')
        .leftJoin('factor', 'pic_map.factor_id', 'factor.id')
        .leftJoin('parameter', 'factor.parameter_id', 'parameter.id')
        .leftJoin('aspect', 'parameter.aspect_id', 'aspect.id')
        .leftJoin('kka', 'aspect.kka_id', 'kka.id')
        .leftJoin('unit_bidang', 'factor.pic_unit_bidang_id', 'unit_bidang.id')
        .select(
          'assessment.*',
          'pic_map.id as assignment_id',
          'pic_map.status as assignment_status',
          'pic_map.assigned_at',
          'factor.id as factor_id',
          'factor.kode as factor_kode',
          'factor.nama as factor_nama',
          'parameter.kode as parameter_kode',
          'parameter.nama as parameter_nama',
          'aspect.kode as aspect_kode',
          'aspect.nama as aspect_nama',
          'kka.kode as kka_kode',
          'kka.nama as kka_nama',
          'unit_bidang.nama as unit_nama'
        )
        .where('pic_map.pic_user_id', userId)
        .orderBy('assessment.created_at', 'desc');

      // Group by assessment
      const groupedAssessments = {};
      assessments.forEach(assignment => {
        const assessmentId = assignment.assessment_id;
        if (!groupedAssessments[assessmentId]) {
          groupedAssessments[assessmentId] = {
            id: assignment.id,
            title: assignment.title,
            assessment_date: assignment.assessment_date,
            status: assignment.status,
            notes: assignment.notes,
            created_at: assignment.created_at,
            updated_at: assignment.updated_at,
            assignments: []
          };
        }
        groupedAssessments[assessmentId].assignments.push({
          assignment_id: assignment.assignment_id,
          assignment_status: assignment.assignment_status,
          assigned_at: assignment.assigned_at,
          factor_id: assignment.factor_id,
          factor_kode: assignment.factor_kode,
          factor_nama: assignment.factor_nama,
          parameter_kode: assignment.parameter_kode,
          parameter_nama: assignment.parameter_nama,
          aspect_kode: assignment.aspect_kode,
          aspect_nama: assignment.aspect_nama,
          kka_kode: assignment.kka_kode,
          kka_nama: assignment.kka_nama,
          unit_nama: assignment.unit_nama
        });
      });

      return Object.values(groupedAssessments);
    } catch (error) {
      logger.error('Error in getPICAssessments:', error);
      throw error;
    }
  }

  async updateAssignmentStatus(assignmentId, status, userId) {
    try {
      const assignment = await this.db('pic_map')
        .where('id', assignmentId)
        .andWhere('pic_user_id', userId)
        .first();

      if (!assignment) {
        throw new Error('Assignment not found or unauthorized');
      }

      await this.db('pic_map')
        .where('id', assignmentId)
        .update({
          status,
          updated_at: new Date()
        });

      // If all assignments for this assessment are completed, update assessment status
      const allAssignments = await this.db('pic_map')
        .where('assessment_id', assignment.assessment_id);

      const allCompleted = allAssignments.every(a => a.status === 'completed');

      if (allCompleted) {
        await this.db('assessment')
          .where('id', assignment.assessment_id)
          .update({
            status: 'completed',
            updated_at: new Date()
          });
      }

      return { success: true, allCompleted };
    } catch (error) {
      logger.error('Error in updateAssignmentStatus:', error);
      throw error;
    }
  }
}

module.exports = new PICAssignmentService();
