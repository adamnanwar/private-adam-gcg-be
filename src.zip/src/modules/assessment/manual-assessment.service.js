const assessmentRepository = require('./assessment.repository');
const logger = require('../../utils/logger-simple');
const { ASSESSMENT_STATUS } = require('./assessment.entity');
// Temporarily use crypto instead of uuid to avoid import issues
const crypto = require('crypto');
function uuidv4() {
  return crypto.randomUUID();
}

// Utility function to check if string is valid UUID
function isValidUUID(str) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
}

class ManualAssessmentService {
  constructor() {
    this.repository = assessmentRepository;
  }

  async createManualAssessment(assessmentData, kkaData, userId) {
    console.log('createManualAssessment called with:', { assessmentData, kkaData, userId });
    const trx = await this.repository.db.transaction();
    
    try {
      // 1. Create Assessment
      const assessment = {
        id: uuidv4(),
        title: assessmentData.title,
        assessment_date: assessmentData.assessment_date,
        assessor_id: assessmentData.assessor_id || userId,
        status: assessmentData.status || ASSESSMENT_STATUS.DRAFT,
        notes: assessmentData.notes || '',
        created_at: new Date(),
        updated_at: new Date()
      };

      const createdAssessment = await trx('assessment')
        .insert(assessment)
        .returning('*')
        .then(rows => rows[0]);

      // 2. Create mapping for client IDs to database IDs
      const idMapping = {
        kka: {},
        aspect: {},
        parameter: {},
        factor: {}
      };

      // 3. Process each KKA and PIC assignments
      console.log('KKA Data check:', Array.isArray(kkaData), kkaData?.length);
      if (Array.isArray(kkaData) && kkaData.length > 0) {
        logger.info(`Processing ${kkaData.length} KKAs with PIC assignments...`);
        console.log('KKA Data received:', JSON.stringify(kkaData, null, 2));
        
        for (const kka of kkaData) {
          console.log('Processing KKA:', kka.kode, kka.nama);
          // Create or get KKA
          let kkaId;
          if (isValidUUID(kka.id)) {
            // Check if KKA exists
            const existingKKA = await trx('kka').where('id', kka.id).first();
            if (existingKKA) {
              kkaId = kka.id;
            } else {
              // Create new KKA with provided UUID
            const [createdKKA] = await trx('kka')
              .insert({
                id: kka.id,
                assessment_id: createdAssessment.id,
                kode: kka.kode,
                nama: kka.nama,
                deskripsi: kka.deskripsi || '',
                created_at: new Date(),
                updated_at: new Date()
              })
              .returning('*');
              kkaId = createdKKA.id;
            }
          } else {
            // Create new KKA with new UUID
              const [createdKKA] = await trx('kka')
              .insert({
                id: uuidv4(),
                assessment_id: createdAssessment.id,
                kode: kka.kode,
                nama: kka.nama,
                deskripsi: kka.deskripsi || '',
                created_at: new Date(),
                updated_at: new Date()
              })
              .returning('*');
            kkaId = createdKKA.id;
          }
          
          idMapping.kka[kka.id] = kkaId;

          // Process aspects
          if (Array.isArray(kka.aspects)) {
            for (const aspect of kka.aspects) {
              let aspectId;
              if (isValidUUID(aspect.id)) {
                const existingAspect = await trx('aspect').where('id', aspect.id).first();
                if (existingAspect) {
                  aspectId = aspect.id;
                } else {
                  const [createdAspect] = await trx('aspect')
                    .insert({
                      id: aspect.id,
                      kka_id: kkaId,
                      kode: aspect.kode,
                      nama: aspect.nama,
                      bobot_indikator: aspect.weight || 1,
                      sort: aspect.sort || 0,
                      created_at: new Date(),
                      updated_at: new Date()
                    })
                    .returning('*');
                  aspectId = createdAspect.id;
                }
              } else {
                const [createdAspect] = await trx('aspect')
                  .insert({
                    id: uuidv4(),
                    kka_id: kkaId,
                    kode: aspect.kode,
                    nama: aspect.nama,
                    bobot_indikator: aspect.weight || 1,
                    sort: aspect.sort || 0,
                    created_at: new Date(),
                    updated_at: new Date()
                  })
                  .returning('*');
                aspectId = createdAspect.id;
              }
              
              idMapping.aspect[aspect.id] = aspectId;

              // Process parameters
              if (Array.isArray(aspect.parameters)) {
                for (const parameter of aspect.parameters) {
                  let parameterId;
                  if (isValidUUID(parameter.id)) {
                    const existingParameter = await trx('parameter').where('id', parameter.id).first();
                    if (existingParameter) {
                      parameterId = parameter.id;
                    } else {
                    const [createdParameter] = await trx('parameter')
                      .insert({
                        id: parameter.id,
                        aspect_id: aspectId,
                        kode: parameter.kode,
                        nama: parameter.nama,
                        bobot_indikator: parameter.weight || 1,
                        sort: parameter.sort || 0,
                        created_at: new Date(),
                        updated_at: new Date()
                      })
                      .returning('*');
                      parameterId = createdParameter.id;
                    }
                  } else {
                    const [createdParameter] = await trx('parameter')
                      .insert({
                        id: uuidv4(),
                        aspect_id: aspectId,
                        kode: parameter.kode,
                        nama: parameter.nama,
                        bobot_indikator: parameter.weight || 1,
                        sort: parameter.sort || 0,
                        created_at: new Date(),
                        updated_at: new Date()
                      })
                      .returning('*');
                    parameterId = createdParameter.id;
                  }
                  
                  idMapping.parameter[parameter.id] = parameterId;

                  // Process factors and PIC assignments
                  if (Array.isArray(parameter.factors)) {
                    for (const factor of parameter.factors) {
                      let factorId;
                      if (isValidUUID(factor.id)) {
                        const existingFactor = await trx('factor').where('id', factor.id).first();
                        if (existingFactor) {
                          factorId = factor.id;
                        } else {
                      const [createdFactor] = await trx('factor')
                        .insert({
                          id: factor.id,
                          parameter_id: parameterId,
                          kode: factor.kode,
                          nama: factor.nama,
                          deskripsi: factor.deskripsi || '',
                          pic_unit_bidang_id: factor.pic_unit_bidang_id,
                          created_at: new Date(),
                          updated_at: new Date()
                        })
                        .returning('*');
                          factorId = createdFactor.id;
                        }
                      } else {
                        const [createdFactor] = await trx('factor')
                          .insert({
                            id: uuidv4(),
                            parameter_id: parameterId,
                            kode: factor.kode,
                            nama: factor.nama,
                            deskripsi: factor.deskripsi || '',
                            pic_unit_bidang_id: factor.pic_unit_bidang_id,
                            created_at: new Date(),
                            updated_at: new Date()
                          })
                          .returning('*');
                        factorId = createdFactor.id;
                      }
                      
                      idMapping.factor[factor.id] = factorId;

                      // Save PIC assignment if provided (now using unit_bidang_id)
                      if (factor.pic_user_id) {
                        // Validate that the unit bidang exists
                        const unitBidang = await trx('unit_bidang')
                          .where('id', factor.pic_user_id)
                          .where('is_active', true)
                          .first();
                        
                        if (!unitBidang) {
                          logger.warn(`Unit bidang ${factor.pic_user_id} not found or inactive, skipping PIC assignment for factor ${factorId}`);
                        } else {
                          await trx('pic_map')
                            .insert({
                              id: uuidv4(),
                              target_type: 'factor',
                              target_id: factorId,
                              unit_bidang_id: factor.pic_user_id, // Now storing unit_bidang_id
                              created_at: new Date(),
                              updated_at: new Date()
                            });
                          
                          logger.info(`PIC assigned: factor ${factorId} -> unit bidang ${factor.pic_user_id}`);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        logger.info('No KKA data to process');
      }

      // 4. KKA relations are already handled in the kka table creation above
      // No need for separate assessment_kka table since kka table has assessment_id

      await trx.commit();
      
      logger.info(`Manual assessment created: ${createdAssessment.id} by user: ${userId}`);
      return {
        assessment: createdAssessment,
        idMapping: idMapping
      };

    } catch (error) {
      await trx.rollback();
      logger.error('Error in createManualAssessment:', error);
      console.error('Error in createManualAssessment:', error);
      console.error('Stack:', error.stack);
      throw error;
    }
  }

  async submitManualResponses(assessmentId, responses, idMapping, userId) {
    const trx = await this.repository.db.transaction();
    
    try {
      // Process each response
      for (const response of responses) {
        // Map client factor ID to database factor ID
        const assessmentFactorId = idMapping.factor[response.factor_id];
        
        if (!assessmentFactorId) {
          logger.warn(`Factor ID ${response.factor_id} not found in mapping, skipping response`);
          continue;
        }

        // Check if response already exists
        const existingResponse = await trx('response')
          .where({
            assessment_id: assessmentId,
            factor_id: assessmentFactorId // Use factor_id instead of assessment_factor_id
          })
          .first();

        if (existingResponse) {
          // Update existing response
          await trx('response')
            .where('id', existingResponse.id)
            .update({
              score: response.score,
              comment: response.comment || '',
              created_by: userId,
              updated_at: new Date()
            });
        } else {
          // Create new response
          await trx('response')
            .insert({
              assessment_id: assessmentId,
              factor_id: assessmentFactorId, // Use factor_id instead of assessment_factor_id
              score: response.score,
              comment: response.comment || '',
              created_by: userId
            });
        }
      }

      await trx.commit();
      logger.info(`Manual responses submitted for assessment: ${assessmentId} by user: ${userId}`);
      return true;

    } catch (error) {
      await trx.rollback();
      logger.error('Error in submitManualResponses:', error);
      throw error;
    }
  }

  async getManualAssessmentStructure(assessmentId) {
    try {
      // Get assessment
      const assessment = await this.repository.db('assessment')
        .where('id', assessmentId)
        .first();

      if (!assessment) {
        throw new Error('Assessment not found');
      }

      // Get KKAs that are assigned to this assessment directly from kka table
      const kkasResult = await this.repository.db('kka')
        .where('assessment_id', assessmentId)
        .where('kka.is_active', true)
        .select('kka.*')
        .orderBy('kka.created_at', 'asc');

      let kkas = kkasResult || [];
      
      if (kkas.length === 0) {
        logger.info(`No KKAs found for assessment ${assessmentId} - user needs to select KKAs`);
        // Return empty array for KKAs - user needs to select them
        return {
          assessment,
          kkas: [],
          responses: []
        };
      } else {
        logger.info(`Found ${kkas.length} KKAs assigned to assessment ${assessmentId}`);
      }

      // Build full hierarchy
      const fullKkas = await Promise.all(
        kkas.map(async (kka) => {
          // Get all active aspects for this KKA
          const aspects = await this.repository.db('aspect')
            .select('aspect.*')
            .where('aspect.kka_id', kka.id)
            .where('aspect.is_active', true)
            .orderBy('aspect.created_at', 'asc');

          const aspectsWithParams = await Promise.all(
            aspects.map(async (aspect) => {
              // Get all active parameters for this aspect
              const parameters = await this.repository.db('parameter')
                .select('parameter.*')
                .where('parameter.aspect_id', aspect.id)
                .where('parameter.is_active', true)
                .orderBy('parameter.created_at', 'asc');

              const parametersWithFactors = await Promise.all(
                parameters.map(async (parameter) => {
                  // Get all active factors for this parameter
                  const factors = await this.repository.db('factor')
                    .select('factor.*')
                    .where('factor.parameter_id', parameter.id)
                    .where('factor.is_active', true)
                    .orderBy('factor.created_at', 'asc');

                  // Get PIC assignments for these factors
                  const factorIds = factors.map(f => f.id);
                  const picAssignments = factorIds.length > 0 
                    ? await this.repository.db('pic_map')
                        .select(
                          'pic_map.id',
                          'pic_map.target_id',
                          'pic_map.target_type',
                          'pic_map.data_unit_id as unit_bidang_id',
                          'pic_map.pic_user_id',
                          'unit_bidang.kode as unit_kode',
                          'unit_bidang.nama as unit_nama',
                          'users.name as pic_name',
                          'users.email as pic_email'
                        )
                        .leftJoin('unit_bidang', 'pic_map.data_unit_id', 'unit_bidang.id')
                        .leftJoin('users', 'pic_map.pic_user_id', 'users.id')
                        .whereIn('pic_map.target_id', factorIds)
                        .where('pic_map.target_type', 'factor')
                    : [];

                  // Create a map of factor_id -> unit_bidang_id
                  const picMap = {};
                  picAssignments.forEach(pic => {
                    picMap[pic.target_id] = pic.unit_bidang_id;
                  });

                  // Get existing responses for these factors
                  const existingResponses = factorIds.length > 0 
                    ? await this.repository.db('response')
                        .select('factor_id', 'score', 'comment')
                        .whereIn('factor_id', factorIds)
                        .where('assessment_id', assessmentId)
                    : [];

                  // Create a map of factor_id -> response
                  const responseMap = {};
                  existingResponses.forEach(response => {
                    responseMap[response.factor_id] = response;
                  });

                  // Map factors with PIC assignments and existing responses
                  const mappedFactors = factors.map(f => {
                    const picAssignment = picAssignments.find(pic => pic.target_id === f.id);
                    const existingResponse = responseMap[f.id];
                    return {
                      id: f.id,
                      parameter_id: f.parameter_id,
                      kode: f.kode,
                      nama: f.nama,
                      deskripsi: f.deskripsi,
                      max_score: f.max_score,
                      sort: f.sort,
                      score: existingResponse?.score || 0,
                      comment: existingResponse?.comment || '',
                      pic_user_id: picAssignment?.pic_user_id || null,
                      pic_name: picAssignment?.pic_name || null,
                      pic_email: picAssignment?.pic_email || null,
                      pic_unit_bidang: picAssignment ? {
                        id: picAssignment.unit_bidang_id,
                        kode: picAssignment.unit_kode,
                        nama: picAssignment.unit_nama
                      } : null,
                      created_at: f.created_at,
                      updated_at: f.updated_at
                    };
                  });

                  return { ...parameter, factors: mappedFactors };
                })
              );

              return { ...aspect, parameters: parametersWithFactors };
            })
          );

          return { ...kka, aspects: aspectsWithParams };
        })
      );

      return {
        assessment,
        kkas: fullKkas
      };

    } catch (error) {
      logger.error('Error in getManualAssessmentStructure:', error);
      throw error;
    }
  }

  async getManualAssessmentResponses(assessmentId) {
    try {
      const responses = await this.repository.db('response')
        .select([
          'response.*',
          'factor.kode as factor_kode',
          'factor.nama as factor_nama'
        ])
        .leftJoin('factor', 'response.factor_id', 'factor.id')
        .where('response.assessment_id', assessmentId);

      // Map responses for frontend
      const mappedResponses = responses.map(response => ({
        factor_id: response.factor_id, // Use direct factor ID since we use master data
        score: response.score,
        comment: response.comment || ''
      }));

      return mappedResponses;

    } catch (error) {
      logger.error('Error in getManualAssessmentResponses:', error);
      throw error;
    }
  }
}

module.exports = new ManualAssessmentService();

