/**
 * AOI Service - Using only assessment_* tables
 */
const AOIRepository = require('./aoi.repository');
const { v4: uuidv4 } = require('uuid');
const emailService = require('../../services/email.service');

class AOIService {
  constructor(db) {
    this.repository = new AOIRepository(db);
  }

  async getAllAOI(options = {}) {
    try {
      return await this.repository.findAllAOI(options);
    } catch (error) {
      throw new Error(`Failed to get AOIs: ${error.message}`);
    }
  }

  async getAOIById(id) {
    try {
      const aoi = await this.repository.findAOIById(id);
      if (!aoi) {
        throw new Error('AOI not found');
      }
      return aoi;
    } catch (error) {
      throw new Error(`Failed to get AOI: ${error.message}`);
    }
  }

  async getAOIByAssessment(assessmentId) {
    try {
      return await this.repository.findAOIByAssessment(assessmentId);
    } catch (error) {
      throw new Error(`Failed to get AOIs by assessment: ${error.message}`);
    }
  }

  async createAOI(aoiData) {
    try {
      // Validate required fields
      if (!aoiData.assessment_id || !aoiData.target_type || !aoiData.target_id || !aoiData.recommendation) {
        throw new Error('Assessment ID, target type, target ID, and recommendation are required');
      }

      // Validate target_type
      const validTargetTypes = ['parameter', 'factor'];
      if (!validTargetTypes.includes(aoiData.target_type)) {
        throw new Error('Invalid target type. Must be one of: parameter, factor');
      }

      // Validate target_id exists in the specified assessment
      const isValidTarget = await this.repository.validateTargetId(
        aoiData.assessment_id,
        aoiData.target_type,
        aoiData.target_id
      );

      if (!isValidTarget) {
        throw new Error('Target ID does not exist in the specified assessment');
      }

      // Prepare AOI data
      const aoiToCreate = {
        id: uuidv4(),
        assessment_id: aoiData.assessment_id,
        target_type: aoiData.target_type,
        target_id: aoiData.target_id,
        recommendation: aoiData.recommendation,
        due_date: aoiData.due_date || null,
        status: aoiData.status || 'open',
        created_by: aoiData.created_by,
        pic_user_id: aoiData.pic_user_id || null
      };

      const createdAOI = await this.repository.createAOI(aoiToCreate);

      // If PIC is assigned, send notification
      if (aoiData.pic_user_id) {
        await this.sendPICNotification(createdAOI.id, aoiData.pic_user_id, 'assignment');
      }

      return createdAOI;
    } catch (error) {
      throw new Error(`Failed to create AOI: ${error.message}`);
    }
  }

  async updateAOI(id, aoiData) {
    try {
      // Check if AOI exists
      const existingAOI = await this.repository.findAOIById(id);
      if (!existingAOI) {
        throw new Error('AOI not found');
      }

      // If target is being updated, validate it
      if (aoiData.target_type || aoiData.target_id) {
        const targetType = aoiData.target_type || existingAOI.target_type;
        const targetId = aoiData.target_id || existingAOI.target_id;
        const assessmentId = aoiData.assessment_id || existingAOI.assessment_id;

        const isValidTarget = await this.repository.validateTargetId(
          assessmentId,
          targetType,
          targetId
        );

        if (!isValidTarget) {
          throw new Error('Target ID does not exist in the specified assessment');
        }
      }

      // Prepare update data
      const updateData = {};
      if (aoiData.recommendation !== undefined) updateData.recommendation = aoiData.recommendation;
      if (aoiData.due_date !== undefined) updateData.due_date = aoiData.due_date;
      if (aoiData.status !== undefined) updateData.status = aoiData.status;
      if (aoiData.target_type !== undefined) updateData.target_type = aoiData.target_type;
      if (aoiData.target_id !== undefined) updateData.target_id = aoiData.target_id;

      return await this.repository.updateAOI(id, updateData);
    } catch (error) {
      throw new Error(`Failed to update AOI: ${error.message}`);
    }
  }

  async deleteAOI(id) {
    try {
      // Check if AOI exists
      const existingAOI = await this.repository.findAOIById(id);
      if (!existingAOI) {
        throw new Error('AOI not found');
      }

      return await this.repository.deleteAOI(id);
    } catch (error) {
      throw new Error(`Failed to delete AOI: ${error.message}`);
    }
  }

  async getAOIStats() {
    try {
      return await this.repository.getAOIStats();
    } catch (error) {
      throw new Error(`Failed to get AOI stats: ${error.message}`);
    }
  }

  async getAOIWithTargetDetails(id) {
    try {
      const aoi = await this.repository.getAOIWithTargetDetails(id);
      if (!aoi) {
        throw new Error('AOI not found');
      }
      return aoi;
    } catch (error) {
      throw new Error(`Failed to get AOI with target details: ${error.message}`);
    }
  }

  /**
   * Get assessment structure for AOI target selection
   */
  async getAssessmentStructure(assessmentId) {
    try {
      // Get aspects from master data (not assessment-specific)
      const aspects = await this.repository.db('aspect')
        .select('aspect.id', 'aspect.kode', 'aspect.nama', 'kka.nama as kka_nama')
        .leftJoin('kka', 'aspect.kka_id', 'kka.id')
        .where('aspect.is_active', true)
        .orderBy('aspect.sort', 'asc');

      // Get parameters for each aspect from master data
      const parameters = await this.repository.db('parameter')
        .select('parameter.id', 'parameter.kode', 'parameter.nama', 'parameter.aspect_id')
        .whereIn('parameter.aspect_id', aspects.map(a => a.id))
        .where('parameter.is_active', true)
        .orderBy('parameter.sort', 'asc');

      // Get factors for each parameter from master data
      const factors = await this.repository.db('factor')
        .select('factor.id', 'factor.kode', 'factor.nama', 'factor.parameter_id')
        .whereIn('factor.parameter_id', parameters.map(p => p.id))
        .where('factor.is_active', true)
        .orderBy('factor.sort', 'asc');

      // Group by hierarchy - only return parameters and factors as valid AOI targets
      const structure = [];
      
      // Add parameters as targets
      parameters.forEach(parameter => {
        structure.push({
          id: parameter.id,
          kode: parameter.kode,
          nama: parameter.nama,
          type: 'parameter',
          label: `Parameter: ${parameter.nama}`
        });
      });
      
      // Add factors as targets
      factors.forEach(factor => {
        structure.push({
          id: factor.id,
          kode: factor.kode,
          nama: factor.nama,
          type: 'factor',
          label: `Faktor: ${factor.nama}`
        });
      });

      return structure;
    } catch (error) {
      // this.logger.error('Error getting assessment structure:', error); // Assuming logger is available
      throw new Error('Failed to get assessment structure');
    }
  }

  /**
   * Get target options for AOI creation
   */
  async getTargetOptions(assessmentId) {
    try {
      const structure = await this.getAssessmentStructure(assessmentId);
      
      // Flatten the structure for easy selection
      const options = [];
      
      // Add aspects
      structure.forEach(aspect => {
        options.push({
          id: aspect.id,
          kode: aspect.kode,
          nama: aspect.nama,
          type: 'aspect',
          label: `Aspek: ${aspect.nama}`
        });
      });

      // Add parameters
      structure.forEach(aspect => {
        aspect.parameters.forEach(parameter => {
          options.push({
            id: parameter.id,
            kode: parameter.kode,
            nama: parameter.nama,
            type: 'parameter',
            label: `Parameter: ${parameter.nama}`
          });
        });
      });

      // Add factors
      structure.forEach(aspect => {
        aspect.parameters.forEach(parameter => {
          parameter.factors.forEach(factor => {
            options.push({
              id: factor.id,
              kode: factor.kode,
              nama: factor.nama,
              type: 'factor',
              label: `Faktor: ${factor.nama}`
            });
          });
        });
      });

      return options;
    } catch (error) {
      // this.logger.error('Error getting target options:', error); // Assuming logger is available
      throw new Error('Failed to get target options');
    }
  }

  /**
   * Assign PIC to AOI and send notification
   */
  async assignPICToAOI(aoiId, picUserId) {
    try {
      // Get AOI details
      const aoi = await this.repository.findAOIById(aoiId);
      if (!aoi) {
        throw new Error('AOI not found');
      }

      // Get PIC user details
      const picUser = await this.repository.db('users')
        .select('id', 'name', 'email')
        .where('id', picUserId)
        .first();

      if (!picUser) {
        throw new Error('PIC user not found');
      }

      // Create or update PIC mapping
      const existingPIC = await this.repository.db('pic_map')
        .where({
          target_type: 'aoi',
          target_id: aoiId
        })
        .first();

      if (existingPIC) {
        // Update existing PIC
        await this.repository.db('pic_map')
          .where('id', existingPIC.id)
          .update({
            pic_user_id: picUserId,
            updated_at: new Date()
          });
      } else {
        // Create new PIC mapping
        await this.repository.db('pic_map').insert({
          id: uuidv4(),
          target_type: 'aoi',
          target_id: aoiId,
          pic_user_id: picUserId,
          created_at: new Date(),
          updated_at: new Date()
        });
      }

      // Send email notification
      try {
        await emailService.sendAOIAssignmentNotification(
          picUser.email,
          picUser.name,
          `AOI-${aoiId.substring(0, 8)}`,
          aoi.recommendation,
          aoi.due_date
        );
      } catch (emailError) {
        logger.warn('Failed to send email notification:', emailError);
        // Don't fail the operation if email fails
      }

      return {
        success: true,
        message: 'PIC assigned successfully',
        pic_user: picUser
      };
    } catch (error) {
      throw new Error(`Failed to assign PIC: ${error.message}`);
    }
  }

  /**
   * Get PIC assignments for AOI
   */
  async getPICAssignments(aoiId) {
    try {
      const picAssignments = await this.repository.db('pic_map')
        .select(
          'pic_map.*',
          'users.name as pic_name',
          'users.email as pic_email'
        )
        .leftJoin('users', 'pic_map.pic_user_id', 'users.id')
        .where({
          'pic_map.assessment_id': aoiData.assessment_id,
          'pic_map.target_id': aoiId
        });

      return picAssignments;
    } catch (error) {
      throw new Error(`Failed to get PIC assignments: ${error.message}`);
    }
  }

  /**
   * Send notification to PIC
   */
  async sendPICNotification(aoiId, picUserId, type, additionalData = null) {
    try {
      // Get AOI details
      const aoi = await this.repository.findAOIById(aoiId);
      if (!aoi) {
        throw new Error('AOI not found');
      }

      // Get PIC details
      const pic = await this.repository.db('users')
        .select('name', 'email')
        .where('id', picUserId)
        .first();

      if (!pic || !pic.email) {
        logger.warn(`No email found for PIC user ${picUserId}`);
        return;
      }

      // Get assessment details
      const assessment = await this.repository.db('assessment')
        .select('title', 'assessment_date')
        .where('id', aoi.assessment_id)
        .first();

      let subject, message;

      switch (type) {
        case 'assignment':
          subject = `Assignment AOI - ${assessment?.title || 'Assessment'}`;
          message = `
            <h2>Assignment Area of Improvement (AOI)</h2>
            <p>Halo ${pic.name},</p>
            <p>Anda telah ditugaskan sebagai PIC untuk Area of Improvement (AOI) dengan detail sebagai berikut:</p>
            <ul>
              <li><strong>Assessment Title:</strong> ${assessment?.title || 'N/A'}</li>
              <li><strong>Tanggal Assessment:</strong> ${assessment?.assessment_date ? new Date(assessment.assessment_date).toLocaleDateString('id-ID') : 'N/A'}</li>
              <li><strong>Rekomendasi:</strong> ${aoi.recommendation}</li>
              <li><strong>Due Date:</strong> ${aoi.due_date ? new Date(aoi.due_date).toLocaleDateString('id-ID') : 'Belum ditentukan'}</li>
            </ul>
            <p>Silakan login ke sistem untuk melihat detail AOI dan melakukan tindak lanjut yang diperlukan.</p>
            <p>Terima kasih.</p>
          `;
          break;

        case 'status_change':
          subject = `Update Status AOI - ${assessment?.title || 'Assessment'}`;
          message = `
            <h2>Update Status Area of Improvement (AOI)</h2>
            <p>Halo ${pic.name},</p>
            <p>Status AOI yang Anda tangani telah diubah:</p>
            <ul>
              <li><strong>Rekomendasi:</strong> ${aoi.recommendation}</li>
              <li><strong>Status Baru:</strong> ${aoi.status}</li>
              <li><strong>Due Date:</strong> ${aoi.due_date ? new Date(aoi.due_date).toLocaleDateString('id-ID') : 'Belum ditentukan'}</li>
            </ul>
            <p>Silakan login ke sistem untuk melihat detail lengkap.</p>
            <p>Terima kasih.</p>
          `;
          break;

        case 'due_date_reminder':
          subject = `Reminder Due Date AOI - ${assessment?.title || 'Assessment'}`;
          message = `
            <h2>Reminder Due Date Area of Improvement (AOI)</h2>
            <p>Halo ${pic.name},</p>
            <p>Ini adalah reminder bahwa AOI yang Anda tangani akan segera jatuh tempo:</p>
            <ul>
              <li><strong>Rekomendasi:</strong> ${aoi.recommendation}</li>
              <li><strong>Due Date:</strong> ${aoi.due_date ? new Date(aoi.due_date).toLocaleDateString('id-ID') : 'Belum ditentukan'}</li>
              <li><strong>Status:</strong> ${aoi.status}</li>
            </ul>
            <p>Silakan segera menyelesaikan tindak lanjut yang diperlukan.</p>
            <p>Terima kasih.</p>
          `;
          break;

        default:
          logger.warn(`Unknown notification type: ${type}`);
          return;
      }

      // Send email
      await emailService.sendEmail({
        to: pic.email,
        subject: subject,
        html: message
      });

      // Store notification in database
      await this.repository.db('aoi_notification')
        .insert({
          id: uuidv4(),
          aoi_id: aoiId,
          user_id: picUserId,
          type: type,
          message: message,
          is_read: false,
          created_at: new Date(),
          updated_at: new Date()
        });

      logger.info(`Notification sent to PIC ${pic.email} for AOI ${aoiId}`);
    } catch (error) {
      logger.error('Error in sendPICNotification:', error);
      throw error;
    }
  }

  /**
   * Get notifications for user
   */
  async getUserNotifications(userId, limit = 10, offset = 0) {
    try {
      const notifications = await this.repository.db('aoi_notification')
        .select(
          'aoi_notification.*',
          'aoi.recommendation',
          'assessment.title'
        )
        .leftJoin('aoi', 'aoi_notification.aoi_id', 'aoi.id')
        .leftJoin('assessment', 'aoi.assessment_id', 'assessment.id')
        .where('aoi_notification.user_id', userId)
        .orderBy('aoi_notification.created_at', 'desc')
        .limit(limit)
        .offset(offset);

      return notifications;
    } catch (error) {
      logger.error('Error in getUserNotifications:', error);
      throw error;
    }
  }

  /**
   * Mark notification as read
   */
  async markNotificationAsRead(notificationId, userId) {
    try {
      await this.repository.db('aoi_notification')
        .where('id', notificationId)
        .where('user_id', userId)
        .update({ is_read: true, updated_at: new Date() });

      logger.info(`Notification ${notificationId} marked as read by user ${userId}`);
    } catch (error) {
      logger.error('Error in markNotificationAsRead:', error);
      throw error;
    }
  }
}

module.exports = AOIService;

